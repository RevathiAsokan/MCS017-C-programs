#include"header.h"
float calc(float p, float r, int t)
{
	float amt;

	amt = p*pow(1+r/100, t);

	return amt;
}