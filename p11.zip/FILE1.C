#include"header.h"
void main()
{
	float principal, int_amt;
	int year;

	float calc(float, float, int);

	printf("Enter principal amount and year: ");
	scanf("%f %d",&principal, &year);

	int_amt = calc(principal, rate, year);
	printf("The interest is %.2f", int_amt);

	getch();
}